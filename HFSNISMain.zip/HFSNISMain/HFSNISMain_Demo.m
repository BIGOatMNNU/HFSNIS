%%% HFSNISMain_Demo
% create by ZiLng Lin
% 2023-4-20
%% HFSNISMain.m+fs
clc;
clear All;

str_data_name = {'Bridges','DD','CLEF','VOC','News20g','ILSVRC65','Car196','Cifar100','Sun'};
str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','ILSVRC65Train.mat','Car196Train.mat','Cifar100Train.mat','SunTrain.mat'};
str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','ILSVRC65Test.mat','Car196Test.mat','Cifar100Test.mat','SunTest.mat'};
str_function_name = {'fs_result_','acc_result_','cd_result_'};

algorithmName = 'HFSNIS';
filePath = 'E:\lzl\123\HFSNISMain\result\0HFSNIS\';

for i = 1:1%length(str_train_name)
    %0 load
    mat_name = str_train_name{i};
    load (mat_name);
    
    %1 algorithm
    delta = 0;
    [~, B, ~, ~, ~] = HFSNISMain(data_array, tree, delta);

    vTime = time;
    vSamples = size(data_array,1);
    vBReducedFeatures = B;
    vFeatureNum = length(vReducedFeaturesB);
    
    %2 save
    fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
    save([filePath, fileName], 'vTime', 'vSamples', 'vBReducedFeatures', 'vFeatureNum');
end