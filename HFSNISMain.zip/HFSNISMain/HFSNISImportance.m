%%% HFSNISImportance
% create by ZiLng Lin
% 2023-4-18
function importOrDepend = HFSNISImportance(samplesMatrix, uni_Y, labels, labelAncestorsArr, current_B_index, current_a_index)
    if(nargin > 5) % ������Ҫ�� ��(B��a) - ��(B)
        %2-3 HigB����HFSNISImportance.m��Ҫ��װ
        denpenBAnda = HFSNISDependence(samplesMatrix(:, [current_B_index, current_a_index]), uni_Y, labels, labelAncestorsArr);
        denpenB = HFSNISDependence(samplesMatrix(:, current_B_index), uni_Y, labels, labelAncestorsArr);

        importOrDepend = (denpenBAnda - denpenB);
    else % ֻ���������� ��(B)
        denpendence = HFSNISDependence(samplesMatrix(:, current_B_index), uni_Y, labels, labelAncestorsArr);
        
        importOrDepend = denpendence;
    end
end